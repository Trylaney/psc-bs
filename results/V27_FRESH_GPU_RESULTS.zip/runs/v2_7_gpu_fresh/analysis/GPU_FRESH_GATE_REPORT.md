# v2.7 Fresh GPU Confirmation — Automatic Gate Report

Tasks: 2880/2880 OK; errors=0
Paired cells: 360

## Aggregate vs safety anchor
- mean Δsmooth-EO²: -0.000513
- mean ΔAUC: +0.001208
- mean Δlogloss: -0.002410
- P(ΔAUC < -0.05): 0.278%
- candidate tail rate: 7.778%

## Against mean of five prevalence-random contexts
- fairness win: 65.000%
- guarded win: 51.667%
- mean ΔAUC: +0.010031

## Frozen GPU gates
- gate1_complete_zero_error: PASS
- gate2_anchor_mean_deo2_lt0: PASS
- gate3_anchor_mean_dauc_ge_m0005: PASS
- gate4_anchor_mean_dll_le_p001: PASS
- gate5_anchor_tail_le_1pct: PASS
- gate6_vs_random5: PASS
- gate7_both_tfms_transfer: PASS
- gate8_not_single_dataset: PASS
- gate9_tail_no_worse_than_candidate: PASS

Overall automatic verdict: PASS
